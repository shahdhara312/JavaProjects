CREATE DATABASE `examsystem`;

CREATE USER 'oesdbuser'@'localhost' IDENTIFIED BY 'password';

GRANT ALL PRIVILEGES ON examsystem.* TO 'oesDbuser'@'localhost' WITH GRANT OPTION;

SHOW GRANTS FOR 'oesDbuser'@'localhost';