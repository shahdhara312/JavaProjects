CREATE TABLE `student` (
  `StudentId` int(11) NOT NULL AUTO_INCREMENT,
  `UserName` varchar(20) DEFAULT NULL,
  `Password` varchar(20) NOT NULL,
  `FirstName` varchar(20) NOT NULL,
  `LastName` varchar(20) NOT NULL,
  `BirthDate` date NOT NULL,
  PRIMARY KEY (`StudentId`),
  UNIQUE KEY `UserName_UNIQUE` (`UserName`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;


CREATE TABLE `question` (
  `QuestionId` int(11) NOT NULL AUTO_INCREMENT,
  `CourseName` varchar(25) NOT NULL,
  `Question` varchar(300) NOT NULL,
  `Option1` varchar(100) NOT NULL,
  `Option2` varchar(100) NOT NULL,
  `Option3` varchar(100) NOT NULL,
  `Option4` varchar(100) NOT NULL,
  `Answer` varchar(100) NOT NULL,
  PRIMARY KEY (`QuestionId`)
) ENGINE=InnoDB AUTO_INCREMENT=116 DEFAULT CHARSET=utf8;

CREATE TABLE `studentanswer` (
  `StudentAnswerId` int(11) NOT NULL AUTO_INCREMENT,
  `StudentId` int(11) NOT NULL,
  `QuestionId` int(11) NOT NULL,
  `CourseName` varchar(25) NOT NULL,
  `StudentAnswer` varchar(100) NOT NULL,
  `RecentFlag` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`StudentAnswerId`),
  KEY `fk_student_studentanswer_idx` (`StudentId`),
  KEY `fk_question_studentanswer_idx` (`QuestionId`),
  CONSTRAINT `studentanswer_ibfk_1` FOREIGN KEY (`QuestionId`) REFERENCES `question` (`QuestionId`)
) ENGINE=InnoDB AUTO_INCREMENT=214 DEFAULT CHARSET=utf8;