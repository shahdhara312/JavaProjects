package npu.edu.exam.webservicereader;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.json.Json;
import javax.json.stream.JsonParser;
import javax.json.stream.JsonParser.Event;
import javax.json.stream.JsonParserFactory;
import javax.servlet.http.HttpSession;

import npu.edu.exam.domain.Question;

public class JsonQuestionListReader {

	static String servletUrlStr = "http://localhost:8080/OnlineExam/jsonQuestions?CourseName=";
	
	private static List<Question> parseQuestionList(JsonParser parser){
		JsonParser.Event event = Event.VALUE_NULL;
		Question question;
		String name = null;
		List<Question> questionList = new ArrayList<Question>();
		
		if (parser.hasNext()) event = parser.next();
		if (event != Event.START_OBJECT) return null; /* Start of QuestionList object  */
		if (parser.hasNext()) event = parser.next();
		
		if (event != Event.KEY_NAME) return null;    
		name = parser.getString();
		if (name == null || !name.equalsIgnoreCase("questionList")) return null;
		/* The key name is correct.  Next look at the value.  We expect is to be an array.  */
		if (parser.hasNext()) event = parser.next();
		if (event != Event.START_ARRAY) return null;
		
		/*  Now process the array.  Each iteration of this loop processes one Question object found in the JSON  */
		while (parser.hasNext()) {
			event = parser.next();
			if (event != Event.START_OBJECT) break;  /* If not start of Question object, exit loop */
			question = parseQuestion(parser);
			questionList.add(question);
		}
		
		if (event != Event.END_ARRAY) return null;    /* End of Question array  */
		if (parser.hasNext()) event = parser.next();  /* End of QuestionList Object */
		if (event != Event.END_OBJECT) return null; 
		
		return questionList;
	}
	
	private static Question parseQuestion(JsonParser parser) {
		JsonParser.Event event = Event.VALUE_NULL;
		String curName = null, curValue;
		Question question = null;
		
		/* Assume START_OBJECT event already parsed  */
		
		question = new Question();
		while (parser.hasNext()) {
			event = parser.next();
			switch(event) {
		      case START_OBJECT:
		    	  System.out.println("Error: Unexpected token type: " + event.toString());
		    	  break;
		      case END_OBJECT:
		    	  return question;   /* finished parsing the Question  */
		      case VALUE_FALSE:
		      case VALUE_NULL:
		      case VALUE_TRUE:
		         System.out.println("Error: Unexpected token type: " + event.toString());
		         break;
		      case KEY_NAME:
		         curName = parser.getString();
		         break;
		      case VALUE_STRING:
		      case VALUE_NUMBER:
		         curValue = parser.getString();
		         addPropertyToQuestion(question, curName, curValue);
		         break;
		      default:
		    	  System.out.println("Error: Unexpected token type: " + event.toString());
		    	  break;
		   }
		}
		
		return question;
	}
	
	private static void addPropertyToQuestion(Question question, String property, String value) {
		int id;
		
		if (property.equalsIgnoreCase("questionId")) {
			id = Integer.parseInt(value);
			question.setQuestionId(id);
			return;
		}
		if (property.equalsIgnoreCase("questionName")) {
			question.setQuestion(value);
			return;
		}
		if (property.equalsIgnoreCase("courseName")) {
			question.setCourseName(value);
			return;
		}
		if (property.equalsIgnoreCase("option1")) {
			question.setOption1(value);
			return;
		}
		if (property.equalsIgnoreCase("option2")) {
			question.setOption2(value);
			return;
		}
		if (property.equalsIgnoreCase("option3")) {
			question.setOption3(value);
			return;
		}
		if (property.equalsIgnoreCase("option4")) {
			question.setOption4(value);
			return;
		}
		if (property.equalsIgnoreCase("answer")) {
			question.setAnswer(value);
			return;
		}
		
		System.out.println("Error: Unexpected property");
	}
	
	private static void printQuestionList(List<Question> questionList) {
		
		//System.out.println("The Question List (from JSON web service) is: \n");
		for (Question curQues: questionList) {
			System.out.println(curQues + "\n");
		}
		
	}
	
	public List<Question> getQuestionListFromWebService(String coursename) {
		List<Question> questionList = new ArrayList<Question>();
		
		
		servletUrlStr = servletUrlStr + coursename;
		System.out.println("URL:" + servletUrlStr);
		try {
			URL jsonQuestionListUrl = new URL(servletUrlStr);
			InputStream urlInStrm = jsonQuestionListUrl.openConnection().getInputStream();
			
			JsonParserFactory factory = Json.createParserFactory(null);
			JsonParser parser = factory.createParser(urlInStrm);

			questionList = parseQuestionList(parser);
			//printQuestionList(questionList);
			servletUrlStr="http://localhost:8080/OnlineExam/jsonQuestions?CourseName=";
			return questionList;
			
		} catch (Exception ex) {
			System.out.println("Problem accessing JSON Servlet: " + ex);
		}
		return questionList;
	}
}
