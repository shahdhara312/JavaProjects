package npu.edu.exam.domain;

public class StudentExam {
	private int studentId;
	private int questionId;
	private int studentAnswerId;
	private String coursename;
	private String studentAns;
	
	public StudentExam() {
		// TODO Auto-generated constructor stub
	}
	
	public StudentExam(int studid, int quesid,String studentans, String coursename ){
		this.studentId = studid;
		this.questionId = quesid;
		this.studentAns = studentans;
		this.setCoursename(coursename);
	}
	
	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}
	public int getStudentId() {
		return studentId;
	}
	
	public void setQuestionId(int questionId) {
		this.questionId = questionId;
	}
	public int getQuestionId() {
		return questionId;
	}
	
	public void setStudentAns(String studentAns) {
		this.studentAns = studentAns;
	}
	public String getStudentAns() {
		return studentAns;
	}

	public int getStudentAnswerId() {
		return studentAnswerId;
	}

	public void setStudentAnswerId(int studentAnswerId) {
		this.studentAnswerId = studentAnswerId;
	}

	public String getCoursename() {
		return coursename;
	}

	public void setCoursename(String coursename) {
		this.coursename = coursename;
	}
}
