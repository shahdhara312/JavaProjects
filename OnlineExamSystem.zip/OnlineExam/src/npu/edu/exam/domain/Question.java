package npu.edu.exam.domain;

public class Question {
	private int questionId;
	private String courseName;
	private String question;
	private String option1;
	private String option2;
	private String option3;
	private String option4;
	private String answer;
	
	public Question() {
		// TODO Auto-generated constructor stub
	}
	
	public int getQuestionId(){
		return questionId;
	}
	public void setQuestionId(int questionId) {
		this.questionId = questionId;
	}
	
	public String getCourseName() {
		return courseName;
	}
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	
	public String getQuestion() {
		return question;
	}
	public void setQuestion(String question) {
		this.question = question;
	}
	
	public String getOption1() {
		return option1;
	}
	public void setOption1(String option1) {
		this.option1 = option1;
	}
	
	public String getOption2() {
		return option2;
	}
	public void setOption2(String option2) {
		this.option2 = option2;
	}
	
	public String getOption3() {
		return option3;
	}
	public void setOption3(String option3) {
		this.option3 = option3;
	}
	
	public String getOption4() {
		return option4;
	}
	public void setOption4(String option4) {
		this.option4 = option4;
	}
	
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stubc
		String str = "\n\n\tQuestion Id: " + questionId+"\n\tCourseName: "+courseName+ "\n\tQuestion: " +question+ 
				"\n\tOption 1: "+option1 + "\n\tOption 2: " + option2 +"\n\tOption 3: " +option3 + "\n\tOption 4: " +option4;
		
		return str;
	}
}
