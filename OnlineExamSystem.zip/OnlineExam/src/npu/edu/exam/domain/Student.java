package npu.edu.exam.domain;

import java.util.Date;



public class Student {

	private int studentId;
	private String fName;
	private String lName;
	private String userName;
	private String password;
	private Date birthdate;
	
	public Student(){
		
	}
	public Student(int studentId,String fname,String lname, String uname,String pswd, Date bdate) {
		this.studentId = studentId;
		this.fName = fname;
		this.lName = lname;
		this.userName = uname;
		this.password = pswd;
		this.birthdate = bdate;		
	}
	
	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}
	public int getStudentId() {
		return studentId;
	}
	
	public void setfName(String fName) {
		this.fName = fName;
	}
	public String getfName() {
		return fName;
	}
	
	public void setlName(String lName) {
		this.lName = lName;
	}
	public String getlName() {
		return lName;
	}
	
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserName() {
		return userName;
	}
	
	public void setPassword(String password) {
		this.password = password;
	}
	public String getPassword() {
		return password;
	}
	
	public void setBirthdate(Date birthdate) {
		this.birthdate = birthdate;
	}
	public Date getBirthdate() {
		return birthdate;
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		String str = "\n\n\tFirst Name: " + fName + "\n\tLast Name: "
				+ lName + "\n\tUser Name: " + userName  + "\n\tBirth Date: "+ birthdate;
		return str;
	}
	
}
