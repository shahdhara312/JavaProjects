package npu.edu.exam.servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import npu.edu.exam.domain.Student;
import npu.edu.exam.exceptions.StudentDbFailure;
import npu.edu.exam.services.StudentServices;

public class LoginServlet extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static String redirectURL;
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		ServletContext context = getServletContext();
		
		response.setContentType("text/html");
		String action;
		action = request.getParameter("action");
		String username = request.getParameter("userName");
		String password = request.getParameter("password");
		
		if (action != null) {
			switch(action){
			 
			}
			
			if (action.equals("Login")) {
				Student studObj = new Student();
				StudentServices studService = new StudentServices();
				
				try {
					studObj = studService.GetStudentDetail(username, password);
				} catch (StudentDbFailure e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				if(studObj!=null){
					// Create Session
					HttpSession session = request.getSession(true);
					
					session.setAttribute("userName", username);
					session.setAttribute("firstName", studObj.getfName());
					session.setAttribute("lastName", studObj.getlName());
					session.setAttribute("studentId", studObj.getStudentId());
					
					request.setAttribute("studentId",studObj.getStudentId());
					
					redirectURL = "/WEB-INF/Views/OESHome.jsp";	
					System.out.println("username is: " + session.getAttribute("userName"));
				}
				else if(studObj == null){
					String message = "OOps!!! Invalid Username/Password";
					request.setAttribute("Error", message);
					redirectURL = "/LoginForm.jsp";
				}
			}
			
		}
		RequestDispatcher dispatch = context.getRequestDispatcher(redirectURL);
		dispatch.forward(request, response);
	}
}
