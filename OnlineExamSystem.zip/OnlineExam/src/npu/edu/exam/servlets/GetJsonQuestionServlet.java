package npu.edu.exam.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.json.*;
import javax.json.stream.*;

import npu.edu.exam.domain.Question;
import npu.edu.exam.exceptions.QuestionDbFailure;
import npu.edu.exam.services.QuestionServices;

@WebServlet("/jsonQuestions")

public class GetJsonQuestionServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	List<Question> questionList = new ArrayList<Question>();
	QuestionServices serviceObj = new QuestionServices();
	
	
	public GetJsonQuestionServlet() {
		// TODO Auto-generated constructor stub
		
		
	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		JsonGeneratorFactory parserFactory = Json.createGeneratorFactory(null);
		JsonGenerator jsonGenerator;

		String coursename = request.getParameter("CourseName");
		//Content type will be JSON
		response.setContentType("application/json");
		try {
			questionList = serviceObj.findQuestionByCourse(coursename);
		} catch (QuestionDbFailure e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		PrintWriter out = response.getWriter();
		jsonGenerator = parserFactory.createGenerator(out);
		questionListToJson(questionList,jsonGenerator);
		jsonGenerator.close();

	}
	private void questionListToJson(List<Question> questionList,
			JsonGenerator jsonGenerator) {
		Question ques;
		jsonGenerator.writeStartObject(); /* Start of QuestionList object */
		jsonGenerator.writeStartArray("Questionlist");

		for (int i = 0; i < questionList.size(); i++) {
			ques = questionList.get(i);
			questionToJson(ques, jsonGenerator);
		}

		jsonGenerator.writeEnd();
		jsonGenerator.writeEnd();
	}
	private void questionToJson(Question question, JsonGenerator jsonGenerator) {

		jsonGenerator.writeStartObject();
		// Writting out name/value pairs
		jsonGenerator.write("questionId", question.getQuestionId());
		jsonGenerator.write("questionName", question.getQuestion());
		jsonGenerator.write("courseName", question.getCourseName());
		jsonGenerator.write("option1", question.getOption1());
		jsonGenerator.write("option2", question.getOption2());
		jsonGenerator.write("option3", question.getOption3());
		jsonGenerator.write("option4", question.getOption4());
		jsonGenerator.write("answer", question.getAnswer());

		jsonGenerator.writeEnd(); // End of Question Object

	}

	
	

}
