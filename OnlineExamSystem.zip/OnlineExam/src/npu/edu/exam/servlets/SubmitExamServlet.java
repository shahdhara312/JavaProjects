package npu.edu.exam.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import npu.edu.exam.domain.StudentExam;
import npu.edu.exam.services.StudentExamServices;

public class SubmitExamServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;
	private static String redirectURL;
	@Override
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session = request.getSession(true);
		ServletContext context = getServletContext();
		Map<String,Integer> resultMap = new HashMap<String,Integer>();
		int studentid = (int) session.getAttribute("studentId");;
		PrintWriter out = response.getWriter();
		String Quesid1 = request.getParameter("1");
		String Quesid2 = request.getParameter("2");
		String Quesid3 = request.getParameter("3");
		System.out.println("Q1 ID: "+Quesid1+" Q2: "+ Quesid2 + " Q3: " + Quesid3);
		
		String ansid1 = request.getParameter(Quesid1.trim());
		String ansid2 = request.getParameter(Quesid2.trim());
		String ansid3 = request.getParameter(Quesid3.trim());
		
		
		String courseName = request.getParameter("CourseName");
			
		StudentExamServices serviceObj = new StudentExamServices();
			StudentExam exam1 = new StudentExam();
			exam1.setStudentId(studentid);
			exam1.setQuestionId(Integer.parseInt(Quesid1));
			exam1.setCoursename(courseName);
			exam1.setStudentAns(ansid1);
			try {
				serviceObj.SubmitStudentExam(exam1);
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
			StudentExam exam2 = new StudentExam();
			exam2.setStudentId(studentid);
			exam2.setQuestionId(Integer.parseInt(Quesid2));
			exam2.setCoursename(courseName);
			exam2.setStudentAns(ansid2);
			try {
				serviceObj.SubmitStudentExam(exam2);
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
			StudentExam exam3 = new StudentExam();
			exam3.setStudentId(studentid);
			exam3.setQuestionId(Integer.parseInt(Quesid3));
			exam3.setCoursename(courseName);
			exam3.setStudentAns(ansid3);
			try {
				serviceObj.SubmitStudentExam(exam3);
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
			// Calculate Score
			try {
				resultMap = serviceObj.CalculateScore(studentid,courseName);
				 Set mapSet = (Set) resultMap.entrySet();
			     Iterator mapIterator = mapSet.iterator();
				while (mapIterator.hasNext()) 
				 {
				     Map.Entry mapEntry = (Map.Entry) mapIterator.next();
				     String key = (String) mapEntry.getKey();
				     Integer value = (Integer) mapEntry.getValue();
				     out.println("<h1>You Scored "+ value + " in " + key + " Exam !!!</h1>");
				     request.setAttribute("score", value);
				     request.setAttribute("courseName", key);
				     redirectURL = "/WEB-INF/Views/viewScore.jsp";
				 }
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			RequestDispatcher dispatch = context.getRequestDispatcher(redirectURL);
			dispatch.forward(request, response);
	}
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
	
		
	}
}
