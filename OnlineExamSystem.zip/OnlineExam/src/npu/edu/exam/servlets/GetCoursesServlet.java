package npu.edu.exam.servlets;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import npu.edu.exam.domain.Question;
import npu.edu.exam.domain.Student;
import npu.edu.exam.exceptions.QuestionDbFailure;
import npu.edu.exam.exceptions.StudentDbFailure;
import npu.edu.exam.services.QuestionServices;
import npu.edu.exam.services.StudentExamServices;
import npu.edu.exam.services.StudentServices;

public class GetCoursesServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static String redirectURL;

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		ServletContext context = getServletContext();
		response.setContentType("text/html");
		HttpSession session = request.getSession();
		Student studObj = new Student();
		StudentServices studService = new StudentServices();
		List<Question> courseList = new ArrayList<Question>();
		Map<String,Integer> scoreMap = new HashMap<String,Integer>();

		String coursename = null;
		String username = (String) session.getAttribute("userName");
		int studentId = (int) session.getAttribute("studentId");

		try {
			courseList = getCourseList();
		} catch (QuestionDbFailure | StudentDbFailure e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		request.setAttribute("courseList", courseList);
		request.setAttribute("studentId", studObj.getStudentId());
		for (Question value : courseList) {
			coursename = value.getCourseName();
			scoreMap = getScore(studentId, coursename);
		}
		request.setAttribute("scoremap", scoreMap);
		redirectURL = "/WEB-INF/Views/viewCourseList.jsp";

		RequestDispatcher dispatch = context.getRequestDispatcher(redirectURL);
		dispatch.forward(request, response);
	}

	private List<Question> getCourseList() throws QuestionDbFailure,
			StudentDbFailure {
		QuestionServices quesService = new QuestionServices();
		List<Question> questionList = null;
		questionList = quesService.findCourseName();
		return questionList;
	}

	
	private Map<String, Integer> getScore(int studentId, String coursename) {

		Map<String, Integer> scoreMap = new HashMap<String, Integer>();
		StudentExamServices examService = new StudentExamServices();
		try {
			scoreMap = examService.CalculateScore(studentId, coursename);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return scoreMap;
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		super.doPost(req, resp);
	}
}
