package npu.edu.exam.servlets;

import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import npu.edu.exam.domain.Question;
import npu.edu.exam.domain.Student;
import npu.edu.exam.domain.StudentExam;
import npu.edu.exam.exceptions.QuestionDbFailure;
import npu.edu.exam.exceptions.StudentDbFailure;
import npu.edu.exam.services.QuestionServices;
import npu.edu.exam.services.StudentExamServices;
import npu.edu.exam.webservicereader.JsonQuestionListReader;

public class GetQuestionPaperServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session = request.getSession(true);
		response.setContentType("text/html");
		String username = (String) session.getAttribute("userName");
		int studentId = (int) session.getAttribute("studentId");
		List<Question> QuestionList = new ArrayList<Question>();
		Map<String,Integer> scoreMap = new HashMap<String,Integer>();
		String coursename = request.getParameter("CourseName");
		//System.out.println("doGet - Course: "+ coursename );
		boolean isUpdate;
		
		try {
			isUpdate = updateExamScore(request);
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		try {

			QuestionList = getAllQuestionList(coursename,request);
			if (QuestionList == null || QuestionList.size() == 0) {
				
				System.out.println("No Questions set !!!");
			}
			else{
				request.setAttribute("QuestionList", QuestionList);
				
				ServletContext context = getServletContext();
		        RequestDispatcher dispatch = context.getRequestDispatcher("/WEB-INF/Views/viewQuestionList.jsp");
		        dispatch.forward(request, response);
		   
			}
		} catch (QuestionDbFailure e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	
	private boolean updateExamScore(HttpServletRequest request) throws SQLException{
		boolean isUpdate = false;
		StudentExamServices examService = new StudentExamServices();
		StudentExam studentExam = new StudentExam();
		studentExam = constructStudentFromRequest(request);
		isUpdate = examService.RetryExam(studentExam);	
		return isUpdate;
	}
	
	private StudentExam constructStudentFromRequest(HttpServletRequest request){
		StudentExam studentExam = new StudentExam();
		HttpSession session = request.getSession(true);
		String coursename = request.getParameter("CourseName");
		int studentId = (int) session.getAttribute("studentId");
		session.setAttribute("courseName", coursename);
		//System.out.println("Contruct - Course: "+ coursename + " Student ID: "+ studentId);
		studentExam.setStudentId(studentId);
		studentExam.setCoursename(coursename);
		
		return studentExam;
	}
	
	private List<Question> getAllQuestionList(String course,HttpServletRequest request) throws QuestionDbFailure,
			StudentDbFailure {
		
		JsonQuestionListReader jsonReader = new JsonQuestionListReader();
		
		//System.out.println("SELECTED COURSE IS: "+course);
		List<Question> questionList = jsonReader.getQuestionListFromWebService(course);
		request.setAttribute("QuestionList", questionList);
		return questionList;
	}

	private Map<String,Integer> getScore(int studentId,String coursename){

		Map<String,Integer> scoreMap = new HashMap<String, Integer>();
		StudentExamServices examService = new StudentExamServices();
		try {
			scoreMap = examService.CalculateScore(studentId, coursename);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return scoreMap;
	}
}
