package npu.edu.exam.servlets;

import java.io.IOException;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import npu.edu.exam.domain.Student;
import npu.edu.exam.exceptions.StudentDbFailure;
import npu.edu.exam.services.StudentServices;

public class RegistrationServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static String redirectURL;
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

		ServletContext context = getServletContext();
		String service = request.getParameter("Service");
		HttpSession session = request.getSession();
	    String studentid = (String)request.getAttribute("studentId");
	    
	    
		switch(service){
			case "addUser":
				int studId = 0;
			try {
				studId = addUser(request);
			} catch (StudentDbFailure e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			request.setAttribute("studentId", studId);	
			redirectURL = "/LoginForm.jsp";
			break;
			case "updateUser":
				boolean isUpdate = false;
			try {
				isUpdate = updateStudent(request);
			} catch (ClassNotFoundException | StudentDbFailure e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			request.setAttribute("isUpdate", isUpdate);
			redirectURL = "/WEB-INF/Views/UpdateProfile.jsp";
				break;
		}
		RequestDispatcher dispatch = context.getRequestDispatcher(redirectURL);
		dispatch.forward(request, response);
	}
	
	private int addUser(HttpServletRequest request) throws StudentDbFailure{
		StudentServices studService = new StudentServices();
		Student newStudent = constructStudentFromRequest(request);
		int newStudId = 0;
		newStudId = studService.InsertStudent(newStudent);
		
		return newStudId;
	}
	
	private boolean updateStudent(HttpServletRequest request) throws ClassNotFoundException, StudentDbFailure, IOException
			 {
		StudentServices studService = new StudentServices();
		Student updateStudent = constructStudentFromRequest(request);
		request.setAttribute("student", updateStudent);
		String studentId = request.getParameter("studentId");
		int studId = Integer.parseInt(studentId);
		updateStudent.setStudentId(studId);
		boolean isUpdate = false;
		isUpdate = studService.UpdateStudentById(updateStudent);
		return isUpdate;
	}
	
	private Student constructStudentFromRequest(HttpServletRequest request){
		Student student = new Student();
		
		student.setfName(request.getParameter("fname"));
		student.setlName(request.getParameter("lname"));
		student.setUserName(request.getParameter("username"));
		student.setPassword(request.getParameter("password"));
		String strDate = request.getParameter("birthDate");
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		Date birthDate = null;
		try {
			birthDate = formatter.parse(strDate);
		} catch (ParseException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		System.out.println(birthDate);
		student.setBirthdate(birthDate);
						
		return student;
	}
	
	
	@Override
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session = request.getSession();
		ServletContext context = getServletContext();
		RequestDispatcher dispatch;
		String service = request.getParameter("Service");
		switch (service) {
		case "addUser":
			redirectURL = "/WEB-INF/Views/registration.jsp";
			break;
		case "updateUser":
			int studentId = (Integer)session.getAttribute("studentId");
			System.out.println( "Student id:" +studentId);
			Student student = getStudentDetails(studentId);
			request.setAttribute("student", student);
			request.setAttribute("Service", "updateUser");
			redirectURL = "/WEB-INF/Views/UpdateProfile.jsp";
			break;
		}
		dispatch = context.getRequestDispatcher(redirectURL);
		dispatch.forward(request, response);
	}
	
	private Student getStudentDetails(int studentId) {
		StudentServices studService = new StudentServices();
		Student student = new Student();
		try {
			student = studService.GetStudentById(studentId);
		} catch (ClassNotFoundException | SQLException | IOException
				| StudentDbFailure e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return student;
	}
}
