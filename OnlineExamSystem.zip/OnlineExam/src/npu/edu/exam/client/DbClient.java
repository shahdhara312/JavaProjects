package npu.edu.exam.client;

import java.io.IOException;
import java.sql.SQLException;
import java.sql.Date;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import npu.edu.exam.domain.Question;
import npu.edu.exam.domain.Student;
import npu.edu.exam.domain.StudentExam;
import npu.edu.exam.exceptions.QuestionDbFailure;
import npu.edu.exam.exceptions.StudentDbFailure;
import npu.edu.exam.services.*;

public class DbClient {

	public static void main(String[] args) throws SQLException,
			ClassNotFoundException, IOException, QuestionDbFailure {
		
		Question quesObj = new Question();
		Student studObj = new Student();
		QuestionServices quesServiceObj = new QuestionServices();
		StudentExamServices examServiceObj = new StudentExamServices();
		StudentServices studServiceObj = new StudentServices();

		// a. Insert new row in the table
		quesObj.setCourseName("CS532");
		quesObj.setQuestion("To run a compiled Java program, the machine must have what loaded and running?");
		quesObj.setOption1("Java virtual machine");
		quesObj.setOption2("Java compiler");
		quesObj.setOption3("Java bytecode");
		quesObj.setOption4("A Web browser");
		quesObj.setAnswer("a");
		//quesServiceObj.insertQuestion(quesObj);
		
		// b.  perform at least two queries (one of which involves the row just inserted) 
		StudentExam exam = new StudentExam(2, 107, "c", "CS510"); 
		
		List<Question> arrQuestion = new ArrayList<Question>();
		arrQuestion = quesServiceObj.findAllQuestion();
		//System.out.println(arrQuestion.toString());
		
		//examServiceObj.SubmitStudentExam(exam);
		
		// c.  remove the row added earlier
		//quesServiceObj.removeQuestion(116);
		
		// d.  repeat the query from b) which should now have a different result  because the row was removed. 
		examServiceObj.SubmitStudentExam(exam);
		
		////////////////////////////////////////////////////////////////////
		/* MORE TRANSACTIONS */
			//  GET STUDENT BY USERNAME
//				try {
//					studObj = studServiceObj.GetStudentByUsername("patel1");
//					System.out.println("/* 1. GET STUDENT BY USERNAME */");
//					System.out.println(studObj.toString());
//					System.out.println("-------------------------------");
//				} catch (StudentDbFailure e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				}

				//  ADD NEW STUDENT
				String strDate = "January 1, 1987 01:01:01.001";
			DateFormat formatter = new SimpleDateFormat("MMMMM d , yyyy hh:mm:ss.SSS");
//
				java.util.Date date = null;
				try {
					date = formatter.parse(strDate);
					} catch (ParseException e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
			}
//				Date sqlDate = new java.sql.Date(date.getTime());
//
//				studObj.setStudentId(6);
//				studObj.setfName("Harshil");
//				studObj.setlName("shah");
//				studObj.setUserName("hns711");
//				studObj.setPassword("hns711");
//				studObj.setBirthdate(sqlDate);
//				int studentId = 0;
//				try {
//					studentId = StudentServices.InsertStudent(studObj);
//				} catch (StudentDbFailure e1) {
//					// TODO Auto-generated catch block
//					e1.printStackTrace();
//				}
//				System.out.println("New Student record added successfully with ID: "+studentId);
//				System.out.println("-------------------------------");
		
				//  GET ALL STUDENT LIST
//				List<Student> arrStudent = new ArrayList<Student>();
//				try {
//					System.out.println("/* 3. GET ALL STUDENT LIST */");
//					arrStudent = studServiceObj.findAllStudent();
//					System.out.println(arrStudent.toString());
//					System.out.println("-------------------------------");
//				} catch (StudentDbFailure e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				}

				//  UPDATE STUDENT DETAIL
//
//		boolean isupdate;
//		try {
//			isupdate = studServiceObj.UpdateStudentById(studObj);
//			if (isupdate) {
//				System.out.println("Data updated successfully");
//			} else {
//				System.out.println("Error !");
//			}
//		} catch (StudentDbFailure e1) {
//			// TODO Auto-generated catch block
//			e1.printStackTrace();
//		}
				

				//  REMOVE STUDENT				
//		boolean isDelete;
//		try {
//			isDelete = studServiceObj.RemoveStudentById(5);
//			if (isDelete) {
//				System.out.println("Data removed successfully");
//			} else {
//				System.out.println("Error !");
//			}
//		} catch (StudentDbFailure e1) {
//			// TODO Auto-generated catch block
//			e1.printStackTrace();
//		}
				 
		
				//  GET DISTINCT COURSE
//				List<Question> arrCourse = new ArrayList<Question>();
//
//				try {
//					arrCourse = quesServiceObj.findCourseName();
//					System.out.println(arrCourse.toString());
//				} catch (QuestionDbFailure e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				}

				//  GET RANDOM QUESTION
//				List<Question> arrQues = new ArrayList<Question>();
//				try {
//					arrQues = quesServiceObj.findQuestionByCourse("CS532");
//					System.out.println(arrQues.toString());
//				} catch (QuestionDbFailure e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				}
		
	}}
