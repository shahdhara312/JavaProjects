package npu.edu.exam.dao;

import java.util.List;

import npu.edu.exam.domain.Student;
import npu.edu.exam.exceptions.StudentDbFailure;

public interface StudentDAO {
	public Student GetStudentDetail(String username,String password) throws StudentDbFailure;
	
	public List<Student> findAllStudent() throws StudentDbFailure;
	
	public Student GetStudentByUsername(String username) throws StudentDbFailure;
	
	public Student GetStudentById(int studentId) throws StudentDbFailure;
	
	public int InsertStudent(Student student) throws StudentDbFailure;
	
	public boolean UpdateStudentById(Student student) throws StudentDbFailure;
	
	public boolean RemoveStudentById(int studentid) throws StudentDbFailure;
	

}
