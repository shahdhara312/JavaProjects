package npu.edu.exam.dao.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.naming.NamingException;

import npu.edu.exam.dao.QuestionDAO;
import npu.edu.exam.database.DbConnection;
import npu.edu.exam.domain.Question;
import npu.edu.exam.exceptions.QuestionDbFailure;

public class QuestionDAOImpl implements QuestionDAO {

	public List<Question> findAllQuestion()  {
		// TODO Auto-generated method stub
		List<Question> findQuestion = new ArrayList<Question>();
		ResultSet results;

		String sqlQuery = "SELECT * FROM Question;";
		try (Connection dbConn = DbConnection.getConnection();
				Statement stmt = dbConn.createStatement()) {
			results = stmt.executeQuery(sqlQuery);

			if (results.next()) {
				// read Question data
				findQuestion = QuestionFactory.constructQuestionList(results);
			}
			results.close();
		} catch (SQLException | NamingException ex) {
			ex.printStackTrace();
		}
		return findQuestion;
	}

	@Override
	public List<Question> findCourseName() throws QuestionDbFailure {
		// TODO Auto-generated method stub
		List<Question> findcourse = new ArrayList<Question>();
		ResultSet results;

		String sqlQuery = "SELECT DISTINCT(CourseName) FROM Question;";
		try (Connection dbConn = DbConnection.getConnection();
				Statement stmt = dbConn.createStatement()) {
			results = stmt.executeQuery(sqlQuery);
			// Question ques = new Question();
			while (results.next()) {
				Question ques = new Question();
				ques.setCourseName(results.getString("CourseName"));
				// findcourse = QuestionFactory.constructQuestionList(results);
				findcourse.add(ques);
			}
			results.close();
		} catch (SQLException | NamingException ex) {
			throw new QuestionDbFailure(QuestionDbFailure.STMT_FAILED);
		}
		return findcourse;
	}

	@Override
	public List<Question> findQuestionByCourse(String coursename)
			throws QuestionDbFailure {
		// TODO Auto-generated method stub
		List<Question> findQues = new ArrayList<Question>();
		ResultSet results;

		String sqlQuery = "SELECT * FROM Question WHERE CourseName = '"
				+ coursename + "'  ORDER BY RAND() LIMIT 4;";
		try (Connection dbConn = DbConnection.getConnection();
				Statement stmt = dbConn.createStatement()) {
			results = stmt.executeQuery(sqlQuery);

			if (results.next()) {
				// read Question data
				findQues = QuestionFactory.constructQuestionList(results);
			}
			results.close();
		} catch (SQLException | NamingException ex) {
			System.err.println("Exception: " + ex);
			throw new QuestionDbFailure(QuestionDbFailure.STMT_FAILED);
		}
		return findQues;
	}

	@Override
	public void insertQuestion(Question newQuestion) throws QuestionDbFailure {
		// TODO Auto-generated method stub
		int rowAffected;
		String insertSql = "INSERT INTO Question(CourseName,Question,Option1,Option2,Option3,Option4,Answer)"
				+ " VALUES (?,?,?,?,?,?,?)";
		int questionId = 0;
		try (Connection dbConn = DbConnection.getConnection()) {
			dbConn.setAutoCommit(false);
			try (PreparedStatement addQuestionStmt = dbConn.prepareStatement(
					insertSql, PreparedStatement.RETURN_GENERATED_KEYS)) {
				addQuestionStmt.setString(1, newQuestion.getCourseName());
				addQuestionStmt.setString(2, newQuestion.getQuestion());
				addQuestionStmt.setString(3, newQuestion.getOption1());
				addQuestionStmt.setString(4, newQuestion.getOption2());
				addQuestionStmt.setString(5, newQuestion.getOption3());
				addQuestionStmt.setString(6, newQuestion.getOption4());
				addQuestionStmt.setString(7, newQuestion.getAnswer());
				rowAffected = addQuestionStmt.executeUpdate();

				if (rowAffected != 1) {
					System.err.print("Transaction is being rolled back");
					dbConn.rollback();
				} else {
					ResultSet rs = addQuestionStmt.getGeneratedKeys();
					if (rs.next()) {
						questionId = rs.getInt(1);
					}
					System.out
							.println("New Question added SuccessFully with Id: "
									+ questionId);
					rs.close();
					dbConn.commit();
				}

			} catch (Exception e) {
				dbConn.rollback();
			}

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}

	@Override
	public void removeQuestion(int questionId) throws QuestionDbFailure {
		// TODO Auto-generated method stub
		String queryStr1 = "DELETE FROM studentanswer WHERE QuestionId = ?";

		String queryStr = "DELETE FROM question WHERE QuestionId = ?";
		int rowsAffected;
		try (Connection dbConn = DbConnection.getConnection()) {
			try (PreparedStatement queryStmt = dbConn
					.prepareStatement(queryStr1)) {
				dbConn.setAutoCommit(false);
				queryStmt.setInt(1, questionId);
				rowsAffected = queryStmt.executeUpdate();

				System.out.println("row deleted successfully !");

				PreparedStatement stmt = dbConn.prepareStatement(queryStr);
				stmt.setInt(1, questionId);
				rowsAffected = stmt.executeUpdate();

				if (rowsAffected == 0) {
					dbConn.rollback();
				} else {
					dbConn.commit();
				}

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				dbConn.rollback();
				e.printStackTrace();
			}

		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (NamingException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
	}

	static class QuestionFactory {
		public static Question constructQuestion(ResultSet results)
				throws SQLException {
			Question ques = new Question();
			ques.setQuestionId(results.getInt("QuestionId"));
			ques.setQuestion(results.getString("Question"));
			ques.setCourseName(results.getString("CourseName"));
			ques.setOption1(results.getString("Option1"));
			ques.setOption2(results.getString("Option2"));
			ques.setOption3(results.getString("Option3"));
			ques.setOption4(results.getString("Option4"));
			ques.setAnswer(results.getString("Answer"));
			return ques;
		}

		public static List<Question> constructQuestionList(ResultSet results)
				throws SQLException {

			List<Question> findQuestion = new ArrayList<Question>();
			Question ques = new Question();

			while (results.next()) {
				ques = constructQuestion(results);
				findQuestion.add(ques);
			}
			return findQuestion;
		}
	}

}
