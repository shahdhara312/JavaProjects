package npu.edu.exam.dao.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.naming.NamingException;

import npu.edu.exam.dao.StudentDAO;
import npu.edu.exam.database.DbConnection;
import npu.edu.exam.domain.Student;
import npu.edu.exam.exceptions.StudentDbFailure;

public class StudentDAOImpl implements StudentDAO {

	@Override
	public List<Student> findAllStudent() throws StudentDbFailure {
		// TODO Auto-generated method stub
		List<Student> findStudent = new ArrayList<Student>();
		ResultSet results;

		String getStudentSql = "SELECT * FROM student ";

		try (Connection dbConn = DbConnection.getConnection();
				Statement getStudentStmt = dbConn.createStatement()) {
			results = getStudentStmt.executeQuery(getStudentSql);

			if (results.next()) {
				// read Student data
				findStudent = StudentFactory.constructStudentList(results);
			}

			results.close();
		} catch (SQLException | NamingException ex) {
			throw new StudentDbFailure(StudentDbFailure.STMT_FAILED);
		}

		return findStudent;
	}
	
	@Override
	public Student GetStudentDetail(String username, String password)
			throws StudentDbFailure {
		// TODO Auto-generated method stub
		Student studObj = null;
		ResultSet results;
		String getStudSql = "SELECT * " + "FROM student "
				+ "WHERE UserName = '" + username + "' "
						+ " AND password = '"+ password +"'";

		try (Connection dbConn = DbConnection.getConnection();
				Statement getStudStmt = dbConn.createStatement()) {
			results = getStudStmt.executeQuery(getStudSql);
			if (!results.next()) {
				//throw new StudentDbFailure(StudentDbFailure.BAD_USERNAME);
				studObj = null;
			} else {
				// read Student data
				studObj = StudentFactory.constructStudent(results);
			}

			results.close();

		} catch (SQLException | NamingException ex) {
			// TODO: handle exception
			ex.printStackTrace();
		}
		return studObj;
	}

	@Override
	public Student GetStudentByUsername(String username) throws StudentDbFailure {
		// TODO Auto-generated method stub
		Student studObj = null;
		ResultSet results;
		String getStudByUsernameSql = "SELECT * " + "FROM student "
				+ "WHERE UserName = '" + username + "'";

		try (Connection dbConn = DbConnection.getConnection();
				Statement getStudByUsernameStmt = dbConn.createStatement()) {
			results = getStudByUsernameStmt.executeQuery(getStudByUsernameSql);
			if (!results.next()) {
				throw new StudentDbFailure(StudentDbFailure.BAD_USERNAME);
			} else {
				// read Student data
				studObj = StudentFactory.constructStudent(results);
			}

			results.close();

		} catch (SQLException | NamingException ex) {
			// TODO: handle exception
			ex.printStackTrace();
		}
		return studObj;
	}

	@Override
	public int InsertStudent(Student student) throws StudentDbFailure {
		// TODO Auto-generated method stub
		int rowAffected;
		String insertSql = "INSERT INTO student(firstname,lastname,username,password,birthdate)"
				+ " VALUES (?,?,?,?,?)";
		int studentId = 0;
		try (Connection dbConn = DbConnection.getConnection()) {
			dbConn.setAutoCommit(false);
			try (PreparedStatement addStudentStmt = dbConn
					.prepareStatement(insertSql,PreparedStatement.RETURN_GENERATED_KEYS)) {
				addStudentStmt.setString(1, student.getfName());
				addStudentStmt.setString(2, student.getlName());
				addStudentStmt.setString(3, student.getUserName());
				addStudentStmt.setString(4, student.getPassword());
				java.util.Date date = student.getBirthdate();
				if (date != null) {
					addStudentStmt.setDate(5, convertJavaDateToSqlDate(date));

				} else {
					addStudentStmt.setDate(5, null);
				}

				rowAffected = addStudentStmt.executeUpdate();

				if (rowAffected != 1) {
					System.err.print("Transaction is being rolled back");
					dbConn.rollback();
				} else {
					dbConn.commit();
				}
				ResultSet rs = addStudentStmt.getGeneratedKeys();
				if (rs.next()) {
					studentId = rs.getInt(1);
				}
				rs.close();
			} catch (Exception e) {
				dbConn.rollback();
			}

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			
		}
		return studentId;
	}
	
	@Override
	public boolean UpdateStudentById(Student student) throws StudentDbFailure {
		// TODO Auto-generated method stub
		String queryStr = "UPDATE student set FirstName = ?,LastName = ? ,BirthDate = ? ,UserName = ?,Password = ? where StudentId = ?";
		int rowsAffected;
		boolean isUpdate = false;
		try (Connection dbConn = DbConnection.getConnection();
				PreparedStatement queryStmt = dbConn.prepareStatement(queryStr)) {

			// Turn off auto-commit so we can use transactions
			dbConn.setAutoCommit(false);

			queryStmt.setString(1, student.getfName());
			queryStmt.setString(2, student.getlName());

			java.util.Date date = student.getBirthdate();
			if (date != null) {
				queryStmt.setDate(3, convertJavaDateToSqlDate(date));
			} else {
				queryStmt.setDate(3, null);
			}
			queryStmt.setString(4, student.getUserName());
			queryStmt.setString(5, student.getPassword());
			queryStmt.setInt(6, student.getStudentId());

			rowsAffected = queryStmt.executeUpdate();

			if (rowsAffected != 1) { /* Exactly one row should have been updated */
				dbConn.rollback();
				if (rowsAffected == 0) {
					throw new StudentDbFailure(StudentDbFailure.RETRY);
				}

				throw new StudentDbFailure(StudentDbFailure.STMT_FAILED);
			}
			isUpdate = true;
			dbConn.commit(); 
		} catch (SQLException | NamingException ex) {
			throw new StudentDbFailure(StudentDbFailure.STMT_FAILED);
		}
		
		return isUpdate;
	}

	@Override
	public boolean RemoveStudentById(int studentid) throws StudentDbFailure {
		// TODO Auto-generated method stub
		String queryStr = "DELETE FROM student where StudentId = ?";
		int rowsAffected;
		boolean isDelete = false;
		try (Connection dbConn = DbConnection.getConnection();
				PreparedStatement queryStmt = dbConn.prepareStatement(queryStr)) {

			// Turn off auto-commit so we can use transactions
			dbConn.setAutoCommit(false);
			queryStmt.setInt(1, studentid);
			rowsAffected = queryStmt.executeUpdate();

			if (rowsAffected != 1) { 
				dbConn.rollback();
				if (rowsAffected == 0) {
					throw new StudentDbFailure(StudentDbFailure.RETRY);
				}

				
				throw new StudentDbFailure(StudentDbFailure.STMT_FAILED);
			}
			isDelete = true;
			dbConn.commit(); 
		} catch (SQLException ex) {
			throw new StudentDbFailure(StudentDbFailure.STMT_FAILED);
		} catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return isDelete;
	}
	
	public static java.sql.Date convertJavaDateToSqlDate(java.util.Date date) {
		return new java.sql.Date(date.getTime());
	}

	static class StudentFactory {

		public static Student constructStudent(ResultSet results)
				throws SQLException {
			Student stud = new Student();
			int id = Integer.parseInt(results.getString("studentId"));
			stud.setStudentId(id);
			stud.setfName(results.getString("firstname"));
			stud.setlName(results.getString("lastname"));
			stud.setUserName(results.getString("userName"));
			stud.setPassword(results.getString("password"));
			stud.setBirthdate(results.getDate("birthdate"));
			return stud;
		}

		public static List<Student> constructStudentList(ResultSet results)
				throws SQLException {

			List<Student> findStudent = new ArrayList<Student>();
			Student stud = new Student();

			while (results.next()) {
				stud = constructStudent(results);
				findStudent.add(stud);
			}
			return findStudent;
		}

	}

	@Override
	public Student GetStudentById(int studentId) throws StudentDbFailure {
		// TODO Auto-generated method stub
		Student studObj = null;
		ResultSet results;
		String getStudByUsernameSql = "SELECT * " + "FROM student "
				+ "WHERE StudentId = '" + studentId + "'";

		try (Connection dbConn = DbConnection.getConnection();
				Statement getStudByUsernameStmt = dbConn.createStatement()) {
			results = getStudByUsernameStmt.executeQuery(getStudByUsernameSql);
			if (!results.next()) {
				throw new StudentDbFailure(StudentDbFailure.BAD_STUD_ID);
			} else {
				// read Student data
				studObj = StudentFactory.constructStudent(results);
			}

			results.close();

		} catch (SQLException | NamingException ex) {
			// TODO: handle exception
			ex.printStackTrace();
		}
		return studObj;
	}

	
	

}
