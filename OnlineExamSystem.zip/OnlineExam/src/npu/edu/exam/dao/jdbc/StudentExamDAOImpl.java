package npu.edu.exam.dao.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.naming.NamingException;

import com.sun.org.apache.bcel.internal.generic.RETURN;

import npu.edu.exam.dao.StudentExamDAO;
import npu.edu.exam.database.DbConnection;
import npu.edu.exam.domain.StudentExam;

public class StudentExamDAOImpl implements StudentExamDAO {

	@Override
	public void SubmitStudentExam(StudentExam exam) throws SQLException {
		// TODO Auto-generated method stub
		int rowAffected;
		String insertSql = "INSERT INTO studentanswer(StudentId,QuestionId,CourseName,StudentAnswer,RecentFlag)"
				+ " VALUES (?,?,?,?,?)";
		int studentAnsId = 0;
		try (Connection dbConn = DbConnection.getConnection()) {
			dbConn.setAutoCommit(false);
			try (PreparedStatement addAnswerStmt = dbConn.prepareStatement(
					insertSql, PreparedStatement.RETURN_GENERATED_KEYS)) {
				addAnswerStmt.setInt(1, exam.getStudentId());
				addAnswerStmt.setInt(2, exam.getQuestionId());
				addAnswerStmt.setString(3, exam.getCoursename());
				addAnswerStmt.setString(4, exam.getStudentAns());
				addAnswerStmt.setString(5, "1");

				rowAffected = addAnswerStmt.executeUpdate();

				if (rowAffected != 1) {
					dbConn.rollback();
				} else {
					dbConn.commit();
				}
				ResultSet rs = addAnswerStmt.getGeneratedKeys();
				if (rs.next()) {
					studentAnsId = rs.getInt(1);
					System.out.println("Student's Answer submitted Successfully with Id: "
							+ studentAnsId);
				}

				rs.close();
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("Exception !");
				dbConn.rollback();
			}

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}

	@Override
	public boolean RetryExam(StudentExam exam) throws SQLException {
		// TODO Auto-generated method stub
		
		String queryStr = "UPDATE studentanswer set RecentFlag = ?"
				+ " where StudentId = ? AND CourseName= ? AND RecentFlag='1'";
		int rowsAffected;
		boolean isUpdate = false;
		try (Connection dbConn = DbConnection.getConnection()) {
			try (PreparedStatement queryStmt = dbConn.prepareStatement(queryStr)) {
				
				dbConn.setAutoCommit(false);

				queryStmt.setString(1, "0"); // The recent flag will be updated with 0
				queryStmt.setInt(2, exam.getStudentId());
				queryStmt.setString(3, exam.getCoursename());

				rowsAffected = queryStmt.executeUpdate();

				if (rowsAffected == 0) {
						dbConn.rollback();
						throw new SQLException("Error while updating record !");
				}else{
					dbConn.commit();
					isUpdate = true;
				}
				
			} catch (SQLException ex) {
				dbConn.rollback();

			}
		} catch (SQLException | NamingException ex) {
			ex.printStackTrace();
		}
		return isUpdate;
	}

	@Override
	public Map<String, Integer> CalculateScore(int studentid,String courseName) throws SQLException {
		// TODO Auto-generated method stub
		
		ResultSet results;
		Map<String,Integer> resultMap = new HashMap<String, Integer>();
		String sqlQuery = "SELECT s.CourseName,"
				+ " SUM(CASE WHEN s.StudentAnswer = q.answer THEN 1 ELSE 0 end) AS Score FROM studentanswer s" 
				+ " join question q " 
				+ " ON q.QuestionId = s.QuestionId "
				+ " WHERE s.StudentId = " + studentid
				+ " AND s.RecentFlag = 1"
				+ " AND s.CourseName ='" + courseName 
				+ "' GROUP BY s.CourseName;";
		try (Connection dbConn = DbConnection.getConnection();
				Statement stmt = dbConn.createStatement()) {
			results = stmt.executeQuery(sqlQuery);

			
			if (results.next()) {
				String coursename = results.getString("CourseName");
				int score = results.getInt("Score");
				resultMap.put(coursename, score);
			}
			results.close();
		} catch (SQLException | NamingException ex) {
			ex.printStackTrace();
		}
		return resultMap;
		
	}

}
