package npu.edu.exam.dao;

import java.util.List;

import npu.edu.exam.domain.Question;
import npu.edu.exam.exceptions.QuestionDbFailure;

public interface QuestionDAO {

	public List<Question> findAllQuestion();
	
	public List<Question> findQuestionByCourse(String coursename) throws QuestionDbFailure;
	
	public void insertQuestion(Question newQuestion) throws QuestionDbFailure;
	
	public List<Question> findCourseName() throws QuestionDbFailure;
	
	public void removeQuestion(int questionId) throws QuestionDbFailure;
}
