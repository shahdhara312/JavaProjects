package npu.edu.exam.dao;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import npu.edu.exam.domain.StudentExam;

public interface StudentExamDAO {
	public void SubmitStudentExam(StudentExam exam)  throws SQLException;
	
	public boolean RetryExam(StudentExam exam) throws SQLException;

	public Map<String,Integer> CalculateScore(int studentid,String coursename) throws SQLException;
}
