package npu.edu.exam.services;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import npu.edu.exam.dao.StudentExamDAO;
import npu.edu.exam.dao.jdbc.StudentExamDAOImpl;
import npu.edu.exam.domain.StudentExam;

public class StudentExamServices {

	StudentExamDAO studExamObj = null;
	
	public StudentExamServices() {
		// TODO Auto-generated constructor stub
		studExamObj = new StudentExamDAOImpl();
	}
	
	public void SubmitStudentExam(StudentExam exam) throws SQLException {
		studExamObj.SubmitStudentExam(exam);
	}
	
	public boolean RetryExam(StudentExam exam) throws SQLException{
		boolean isUpdate = studExamObj.RetryExam(exam);
		return isUpdate;
	}
	
	public Map<String, Integer> CalculateScore(int studentId,String coursename) throws SQLException{
		Map<String,Integer> resultMap = new HashMap<String,Integer>();
		resultMap = studExamObj.CalculateScore(studentId,coursename);
		return resultMap;
	}
}
