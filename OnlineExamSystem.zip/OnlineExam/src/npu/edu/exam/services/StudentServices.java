package npu.edu.exam.services;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import npu.edu.exam.dao.StudentDAO;
import npu.edu.exam.dao.jdbc.StudentDAOImpl;
import npu.edu.exam.domain.Student;
import npu.edu.exam.exceptions.StudentDbFailure;

public class StudentServices {
	static StudentDAO studentDAO = null;
	
	public StudentServices() {
		// TODO Auto-generated constructor stub
		studentDAO = new StudentDAOImpl();
	}
	public List<Student> findAllStudent() throws StudentDbFailure {
		List<Student> findStudentList = studentDAO.findAllStudent();	
		return findStudentList;
	}

	public Student GetStudentDetail(String username,String password) throws StudentDbFailure{
		Student getStudent = studentDAO.GetStudentDetail(username, password);
		return getStudent;
	}
	public Student GetStudentByUsername(String username)
			throws SQLException, ClassNotFoundException, IOException,
			StudentDbFailure {
		Student getStudent = studentDAO.GetStudentByUsername(username);
		return getStudent;		
	}
	
	public Student GetStudentById(int studentId)
			throws SQLException, ClassNotFoundException, IOException,
			StudentDbFailure {
		Student getStudent = studentDAO.GetStudentById(studentId);
		return getStudent;		
	}

	public int InsertStudent(Student student) throws StudentDbFailure {
		
		int studentId = studentDAO.InsertStudent(student);
		return studentId;
	}

	public boolean UpdateStudentById(Student student)
			throws StudentDbFailure, ClassNotFoundException, IOException {
		
		boolean isUpdate = studentDAO.UpdateStudentById(student);
		
		return isUpdate;
	}
	
	public boolean RemoveStudentById(int studentid) throws StudentDbFailure{
		
		boolean isDelete = studentDAO.RemoveStudentById(studentid);
		return isDelete;
	}
}
