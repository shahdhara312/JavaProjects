package npu.edu.exam.services;

import java.util.List;

import npu.edu.exam.dao.QuestionDAO;
import npu.edu.exam.dao.jdbc.QuestionDAOImpl;
import npu.edu.exam.domain.Question;
import npu.edu.exam.exceptions.QuestionDbFailure;

public class QuestionServices {

	 QuestionDAO questionDAO = null;

	public QuestionServices() {
		// TODO Auto-generated constructor stub
		questionDAO = new QuestionDAOImpl();
	}
	public List<Question> findAllQuestion() {
		List<Question> findQuestionList = questionDAO.findAllQuestion();
		
		return findQuestionList;
	}
	
	public List<Question> findCourseName() throws QuestionDbFailure{
		List<Question> findCourseList = questionDAO.findCourseName();
		
		return findCourseList;
	}
	
	public List<Question> findQuestionByCourse(String coursename)
			throws QuestionDbFailure{
		QuestionDAO ques = new QuestionDAOImpl();
		List<Question> findQuestionList = ques.findQuestionByCourse(coursename);
		return findQuestionList;
	}
	
	public void insertQuestion(Question newQuestion) throws QuestionDbFailure{
		questionDAO.insertQuestion(newQuestion);
		
	}
	
	public void removeQuestion(int questionId) throws QuestionDbFailure{
		questionDAO.removeQuestion(questionId);
	}
}
